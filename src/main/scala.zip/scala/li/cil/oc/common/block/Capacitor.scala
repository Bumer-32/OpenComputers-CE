package li.cil.oc.common.block

import java.util.Random

import li.cil.oc.common.tileentity
import net.minecraft.world.level.block.state.BlockBehaviour.{Properties => Properties}
import net.minecraft.world.level.block.{Block => Block}
import net.minecraft.world.level.block.state.{BlockState => BlockState}
import net.minecraft.core.{BlockPos => BlockPos}
import net.minecraft.world.level.{BlockGetter => IBlockReader}
import net.minecraft.world.level.{Level => World}
import net.minecraft.server.level.{ServerLevel => ServerWorld}

class Capacitor(props: Properties) extends SimpleBlock(props) {
  @Deprecated
  override def isRandomlyTicking(state: BlockState) = true

  // ----------------------------------------------------------------------- //

  override def newBlockEntity(pos: BlockPos, state: BlockState) = new tileentity.Capacitor(pos, state)

  // ----------------------------------------------------------------------- //

  override def hasAnalogOutputSignal(state: BlockState): Boolean = true

  override def getAnalogOutputSignal(state: BlockState, world: World, pos: BlockPos): Int =
    world.getBlockEntity(pos) match {
      case capacitor: tileentity.Capacitor if !world.isClientSide =>
        math.round(15 * capacitor.node.localBuffer / capacitor.node.localBufferSize).toInt
      case _ => 0
    }

  override def tick(state: BlockState, world: ServerWorld, pos: BlockPos, rand: Random): Unit = {
    world.updateNeighborsAt(pos, this)
  }

  @Deprecated
  override def neighborChanged(state: BlockState, world: World, pos: BlockPos, block: Block, fromPos: BlockPos, b: Boolean): Unit =
    world.getBlockEntity(pos) match {
      case capacitor: tileentity.Capacitor => capacitor.recomputeCapacity()
      case _ =>
    }
}
