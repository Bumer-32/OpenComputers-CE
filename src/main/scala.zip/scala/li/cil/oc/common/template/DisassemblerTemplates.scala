package li.cil.oc.common.template

import java.lang.reflect.Method

import li.cil.oc.OpenComputers
import li.cil.oc.common.IMC
import net.minecraft.world.item.ItemStack
import net.minecraft.nbt.CompoundTag

import scala.collection.mutable

object DisassemblerTemplates {
  private val templates = mutable.ArrayBuffer.empty[Template]

  def add(template: CompoundTag): Unit = try {
    val selector = IMC.getStaticMethod(template.getString("select"), classOf[ItemStack])
    val disassembler = IMC.getStaticMethod(template.getString("disassemble"), classOf[ItemStack], classOf[Array[ItemStack]])

    templates += new Template(selector, disassembler)
  }
  catch {
    case t: Throwable => OpenComputers.log.warn("Failed registering disassembler template.", t)
  }

  def select(stack: ItemStack) = templates.find(_.select(stack))

  class Template(val selector: Method,
                 val disassembler: Method) {
    def select(stack: ItemStack) = IMC.tryInvokeStatic(selector, stack)(false)

    def disassemble(stack: ItemStack, ingredients: Array[ItemStack]) = {
      val result = IMC.tryInvokeStatic(disassembler, stack, ingredients)(null: Array[_])
      Option(result).map(_.toSeq).getOrElse(Seq.empty) match {
        case Seq(stacks: Array[ItemStack], drops: Array[ItemStack]) =>
          (Some(stacks), Some(drops))
        case Seq(stack: ItemStack, drops: Array[ItemStack]) =>
          (Some(Array[ItemStack](stack)), Some(drops))
        case Seq(stacks: Array[ItemStack], drop: ItemStack) =>
          (Some(stacks), Some(Array[ItemStack](drop)))
        case Seq(stacks: Array[ItemStack]) =>
          (Some(stacks), None)
        case _ => (None, None)
      }
    }
  }

}
