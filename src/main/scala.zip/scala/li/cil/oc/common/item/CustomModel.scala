package li.cil.oc.common.item

import net.minecraft.world.item.ItemStack
import net.minecraftforge.client.event.ModelBakeEvent
import net.minecraftforge.api.distmarker.Dist
import net.minecraftforge.api.distmarker.OnlyIn
import net.minecraft.client.resources.model.ModelResourceLocation

trait CustomModel {
  @OnlyIn(Dist.CLIENT)
  def getModelLocation(stack: ItemStack): ModelResourceLocation

  @OnlyIn(Dist.CLIENT)
  def registerModelLocations(): Unit = {}

  @OnlyIn(Dist.CLIENT)
  def bakeModels(bakeEvent: ModelBakeEvent): Unit = {}
}
