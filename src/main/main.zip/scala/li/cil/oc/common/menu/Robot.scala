package li.cil.oc.common.menu

import li.cil.oc.api
import li.cil.oc.client.Textures
import li.cil.oc.common
import li.cil.oc.common.ComponentTracker
import li.cil.oc.common.tileentity
import li.cil.oc.integration.opencomputers.DriverKeyboard
import li.cil.oc.integration.opencomputers.DriverScreen
import li.cil.oc.util.SideTracker
import net.minecraftforge.api.distmarker.Dist
import net.minecraftforge.api.distmarker.OnlyIn
import net.minecraft.network.FriendlyByteBuf
import net.minecraft.world.inventory.MenuType
import net.minecraft.world.entity.player.Inventory
import net.minecraft.world.Container
import net.minecraft.world.item.ItemStack
import net.minecraft.world.inventory.DataSlot
import net.minecraft.resources.ResourceLocation

object RobotInfo {
  def getScreenBuffer(robot: tileentity.Robot): Option[String] = robot.components.collectFirst {
    case Some(buffer: api.internal.TextBuffer) if buffer.node != null => buffer.node.address
  }

  def hasKeyboard(robot: tileentity.Robot) = robot.info.components.map(api.Driver.driverFor(_, robot.getClass)).contains(DriverKeyboard)

  def readRobotInfo(buff: FriendlyByteBuf): RobotInfo = {
    val mainInvSize = buff.readVarInt()
    val slot1 = buff.readUtf(32)
    val tier1 = buff.readVarInt()
    val slot2 = buff.readUtf(32)
    val tier2 = buff.readVarInt()
    val slot3 = buff.readUtf(32)
    val tier3 = buff.readVarInt()
    val screenBuffer = buff.readBoolean() match {
      case true => Some(buff.readUtf())
      case false => None
    }
    val hasKeyboard = buff.readBoolean()
    new RobotInfo(mainInvSize, slot1, tier1, slot2, tier2, slot3, tier3, screenBuffer, hasKeyboard)
  }
  
  def writeRobotInfo(buff: FriendlyByteBuf, info: RobotInfo): Unit = {
    buff.writeVarInt(info.mainInvSize)
    buff.writeUtf(info.slot1, 32)
    buff.writeVarInt(info.tier1)
    buff.writeUtf(info.slot2, 32)
    buff.writeVarInt(info.tier2)
    buff.writeUtf(info.slot3, 32)
    buff.writeVarInt(info.tier3)
    info.screenBuffer match {
      case Some(addr) => {
        buff.writeBoolean(true)
        buff.writeUtf(addr)
      }
      case _ => buff.writeBoolean(false)
    }
    buff.writeBoolean(info.hasKeyboard)
  }
}

class RobotInfo(val mainInvSize: Int, val slot1: String, val tier1: Int,
    val slot2: String, val tier2: Int, val slot3: String, val tier3: Int,
    val screenBuffer: Option[String], val hasKeyboard: Boolean) {

  def this(robot: tileentity.Robot) = this(robot.mainInventory.getContainerSize, robot.containerSlotType(1), robot.containerSlotTier(1),
    robot.containerSlotType(2), robot.containerSlotTier(2), robot.containerSlotType(3), robot.containerSlotTier(3),
    RobotInfo.getScreenBuffer(robot), RobotInfo.hasKeyboard(robot))
}

class Robot(selfType: MenuType[_ <: Robot], id: Int, playerInventory: Inventory, robot: Container, val info: RobotInfo)
  extends AbstractMenu(selfType, id, playerInventory, robot) {

  private val withScreenHeight = 256
  private val noScreenHeight = 108
  val deltaY: Int = if (info.screenBuffer.isDefined) 0 else withScreenHeight - noScreenHeight

  override protected def getHostClass = classOf[tileentity.Robot]

  addSlotToContainer(170 + 0 * slotSize, 232 - deltaY, common.Slot.Tool)
  addSpecialSlot(170 + 1 * slotSize, 232 - deltaY, info.slot1, info.tier1)
  addSpecialSlot(170 + 2 * slotSize, 232 - deltaY, info.slot2, info.tier2)
  addSpecialSlot(170 + 3 * slotSize, 232 - deltaY, info.slot3, info.tier3)

  // Like addSlotToContainer, but handles the very special, much edge case with screen & keyboard.
  def addSpecialSlot(x: Int, y: Int, slot: String, tier: Int): Unit = {
    val index = slots.size
    addSlot(new StaticComponentSlot(this, otherInventory, index, x, y, getHostClass, slot, tier) {
      override def mayPlace(stack: ItemStack): Boolean = {
        if (DriverScreen.worksWith(stack, getHostClass)) return false
        if (DriverKeyboard.worksWith(stack, getHostClass)) return false
        super.mayPlace(stack)
      }
    })
  }

  // Slot.x and Slot.y are final, so have to rebuild when scrolling
  def generateSlotsFor(scroll: Int): Unit = {
    val maxRows = math.max(info.mainInvSize / 4, 4)
    for (i <- 0 until maxRows) {
      val y = 156 + (i - scroll) * slotSize - deltaY
      for (j <- 0 to 3) {
        val x = 170 + j * slotSize
        val idx = 4 + j + 4 * i
        val slot = new InventorySlot(this, otherInventory, idx, x, y, i >= scroll && i < scroll + 4)
        slot.index = idx
        if (slots.size() <= idx) addSlot(slot)
        else slots.set(idx, slot)
      }
    }
  }
  generateSlotsFor(0)

  addPlayerInventorySlots(6, 174 - deltaY)

  // This factor is used to make the energy values transferable using
  // MCs 'progress bar' stuff, even though those internally send the
  // values as shorts over the net (for whatever reason).
  private val factor = 100

  private val globalBufferData = robot match {
    case te: tileentity.Robot => {
      addDataSlot(new DataSlot {
        override def get(): Int = te.globalBuffer.toInt / factor

        override def set(value: Int): Unit = te.globalBuffer = value * factor
      })
    }
    case _ => addDataSlot(DataSlot.standalone)
  }
  def globalBuffer = globalBufferData.get * factor

  private val globalBufferSizeData = robot match {
    case te: tileentity.Robot => {
      addDataSlot(new DataSlot {
        override def get(): Int = te.globalBufferSize.toInt / factor

        override def set(value: Int): Unit = te.globalBufferSize = value * factor
      })
    }
    case _ => addDataSlot(DataSlot.standalone)
  }
  def globalBufferSize = globalBufferSizeData.get * factor

  private val runningData = robot match {
    case te: tileentity.Robot => {
      addDataSlot(new DataSlot {
        override def get(): Int = if (te.isRunning) 1 else 0

        override def set(value: Int): Unit = te.setRunning(value != 0)
      })
    }
    case _ => addDataSlot(DataSlot.standalone)
  }
  def isRunning = runningData.get != 0

  private val selectedSlotData = robot match {
    case te: tileentity.Robot => {
      addDataSlot(new DataSlot {
        override def get(): Int = te.selectedSlot

        override def set(value: Int): Unit = te.setSelectedSlot(value)
      })
    }
    case _ => addDataSlot(DataSlot.standalone)
  }
  def selectedSlot = selectedSlotData.get

  class InventorySlot(container: AbstractMenu, inventory: Container, index: Int, x: Int, y: Int, enabled: Boolean)
    extends StaticComponentSlot(container, inventory, index, x, y, getHostClass, common.Slot.Any, common.Tier.Any) {

    def isValid: Boolean = getSlotIndex >= 4 && getSlotIndex < 4 + info.mainInvSize

    @OnlyIn(Dist.CLIENT) override
    def isActive: Boolean = enabled && isValid && super.isActive

    @OnlyIn(Dist.CLIENT)
    override def getBackgroundLocation: ResourceLocation =
      if (isValid) super.getBackgroundLocation
      else Textures.Icons.get(common.Tier.None)

    override def getItem: ItemStack = {
      if (isValid) super.getItem
      else ItemStack.EMPTY
    }
  }

}
