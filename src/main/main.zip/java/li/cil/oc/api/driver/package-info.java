/**
 * This package contains driver related interfaces.
 * <br>
 * Drivers are used to add items and third party blocks to the internal network,
 * which is mostly used to make components wrapping them available to computers.
 */
package li.cil.oc.api.driver;

import li.cil.oc.api.API;